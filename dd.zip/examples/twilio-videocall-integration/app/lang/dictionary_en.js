export default{
  END_DL: "Ends analysis and download CSV",
  SHARE_URL: "Share this URL with the invitee",
  WAITING_CLIENT: "Waiting the invitee to join the call... ",
  LINK_COPIED: "Link copied successfully",
  SHARE_BTN: "Copy URL",
  CREATE_ROOM: "Create video-call",
  USERN_NAME: "Invitee name",
  CONTINUE:"Continue",
  ALLOW_CAMERA: "Asking camera permission",
  CAMERA_DENIED: "We were not able to access camera, permission denied",
  ENTER: "Enter"

};
