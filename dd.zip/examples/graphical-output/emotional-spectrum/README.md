# Emotional spectrum example

## Usage

Serve the index.html file using a web server, remote or local (e.g. http://localhost), 
or you can fork [this JSFiddle](https://jsfiddle.net/morphcast/06adnLou/).

## Demo

You can also run it right now, using this [live demo](https://jsfiddle.net/morphcast/06adnLou/show) version.
